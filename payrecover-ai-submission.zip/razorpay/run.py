"""
PayRecover AI - Main Application Runner
=======================================
Runs data generation, ML training (if needed), database initialization,
and starts the FastAPI web server on host 0.0.0.0:8000 (accessible on PC and Phone).
"""

import os
import sys
import socket
import uvicorn

# Set UTF-8 output encoding for Windows consoles
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")

from backend.database import init_db
from backend.ml_model import METRICS_FILE, train_and_evaluate

def get_local_ip():
    """Get the local IP address of this PC on the Wi-Fi / LAN network."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

def start():
    print("=" * 60)
    print("  PayRecover AI – Intelligent Payment Recovery Agent")
    print("  Razorpay AI Builder Internship 2026 – Track 3")
    print("=" * 60)
    
    # 1. Initialize database & synthetic dataset
    print("\n[Step 1] Initializing SQLite database & synthetic transactions...")
    init_db()
    
    # 2. Train ML model if not already trained
    if not os.path.exists(METRICS_FILE):
        print("\n[Step 2] Training ML model...")
        train_and_evaluate()
    else:
        print("\n[Step 2] Pre-trained ML model loaded successfully.")
        
    local_ip = get_local_ip()
    print("\n[Step 3] Starting FastAPI server on all interfaces (0.0.0.0:8000)...")
    print(f"-> On this PC : http://localhost:8000")
    print(f"-> On your Phone: http://{local_ip}:8000  (Make sure phone & PC are on the same Wi-Fi / Hotspot)")
    print("-> Press Ctrl+C to terminate the server.\n")
    
    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=False)

if __name__ == "__main__":
    start()
